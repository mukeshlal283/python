def table(num):

    for i in range(1, 11):
        a =  print(num * i)

    return a

print(table(5))