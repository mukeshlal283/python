# (0°C × 9/5) + 32 = 32°F

def temperature(n):
    return  n * (9/5) + 32

print(temperature(0))
