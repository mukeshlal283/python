
file = open("creat_by_02program.txt", "a")
file.write("now close this file")
file.close()

#also use
#open("creat_by_02program.txt", "a").write("now close this file")