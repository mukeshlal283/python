
file = open("creat_by_02program.txt", "w")
file.write("hello my name is mukesh lal.")
file.close()

#you can also use
#open("creat_by_02program.txt", "w").write("hello my name is mukesh lal")