class Freind:

    def __init__(anything, name): #use can use any random work instead of "self"
        anything.name = name
        print("hello", name)

f1 = Freind("rohan")