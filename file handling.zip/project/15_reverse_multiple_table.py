num = int(input("enter the table = "))

for i in reversed(range(11)):
    print(num * i)