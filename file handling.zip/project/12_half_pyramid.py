num = int(input("enter the number = "))

for i in range(num):
    print("*" * (i+1))