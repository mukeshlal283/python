num =  int(input("enter the number = "))
sum = 0
i=0

while (i <= num):
    sum = sum + i 
    i= i + 1

print(sum)
